        </section>
    </section>
    <footer>
        <p>&copy; 2022 - DIAN TRI HANDAYANI - 312010041 </p>
    </footer>
    </div>
</body>
</html>